# ZHKB_Android_05_Map
Работа с картами Google

![Screenshot](screen1.png)

![Screenshot](screen2.png)
